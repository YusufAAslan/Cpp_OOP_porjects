#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <time.h>
#include "simulation.h"
using namespace std;


int poison_ant = 0 ; // count of poisonous ants its not constant  there is no intial poisonous ant  will be used later 

// World class's constructor defintion

 World::World()
{
	// initialze world to empty spaces at the start

	int i , j ;
	for ( i = 0; i < worldSize; ++i)
	{
		for ( j = 0; j <worldSize ; ++j)
		{
			grid[i][j]=NULL;

		}
	}

}


// Member functions defintions


// getAt function to return the location 
Organism* World::getAt(int x, int y)
{	

	if (( x >= 0) && (x<worldSize) && (y>=0) &&(y<worldSize) )
	{
		return grid[x][y];
	}
	return NULL;

}



// Defintion of setAt function which will put things in cell
void World::setAt(int x , int y, Organism *org)
{
	if ((x>=0) && (x<worldSize) && (y>0) && (y<worldSize))
	{
		grid[x][y] = org;
	}
}



//Defintion of display function just to show the world on screen
void World::display()
{
	int i , j,counter=0 ;
	cout<<endl<<endl;
	for ( j = 0; j < worldSize; ++j)
	{
		for ( i = 0; i < worldSize; ++i)
		{
			if (grid[i][j] == NULL)
			{
				cout<<"-";

			}
			else if (grid[i][j]->getType()==ant) // put o to refer to ant 
			{
				cout<<"o";
			}
			else if (grid[i][j]->getType()==poison_ant) // put c to refer to ant 
			{
				cout<<"c";
			}
			else
				cout<<"X";	//to display doodlebugs 
		}// end for i

		cout<<endl;


	}//end for j
		// cout<<" display finish"<<endl;



}


//Defintion of simulateOneStep

void World::simulateOneStep()
{
	int i , j ;
	// first reset all creatures to not moved

	for ( i = 0; i < worldSize; ++i)
	{
		for ( j = 0; j < worldSize; ++j)
		{
			if (grid[i][j] != NULL)
			{
				grid[i][j] -> moved =false;
			}
		}// end for i


	}// end for j


	// loop for doodlebug  to check the borders if empty  and move if it's possible
	for ( i = 0; i < worldSize; ++i)
	{
		for (j = 0; j < worldSize; ++j)
		{
			if ((grid[i][j] != NULL) && (grid[i][j]->getType() == doodleBug))
			{
				if (grid[i][j] -> moved == false)
				{
					grid[i][j] -> moved = true;
					grid[i][j] -> move();
				}
			}


		}//end for i


	}//end for j



	// loop for Ant  to check the borders if empty  and move if it's possible
	
	for ( i = 0; i < worldSize; ++i)
		{
			for ( j = 0; j < worldSize; ++j)
			{
				if ((grid[i][j] != NULL) && (grid[i][j] -> getType() == ant))
				{
					if (grid[i][j] -> moved == false)
					{
						grid[i][j] -> moved = true;
						grid[i][j] -> move();
					}
				}
			}  // end for j


		}// end for i




	// loop for poison ant  to check the borders if empty  and move if it's possible

	for ( i = 0; i < worldSize; ++i)
		{
			for ( j = 0; j < worldSize; ++j)
			{
				if ((grid[i][j] != NULL) && (grid[i][j] -> getType() == poison_ant))
				{
					if (grid[i][j] -> moved == false)
					{
						grid[i][j] -> moved = true;
						grid[i][j] -> move();
					}
				}
			}  // end for j


		}// end for i



	// loop for doodlebug  to check the borders   and eat(breed) if it's possible
		// also check if any doodlebug  haven't
		// eaten recently and kill it (delete)

		for ( i = 0; i < worldSize; ++i)
		{
			for ( j = 0; j < worldSize; ++j)
			{

			
				if ((grid[i][j] != NULL) && (grid[i][j] -> getType() == doodleBug))
				{
					if (grid[i][j] -> starve())
					{
						delete (grid[i][j]);
						grid[i][j] = NULL;
					}
				}
			}// end for j


		} // end for i



	// loop for ant  to check the borders   and eat(breed) if it's possible
		for ( i = 0; i < worldSize; ++i)
		{
			for ( j = 0; j < worldSize; ++j)
			{
				if ((grid[i][j] != NULL) && (grid[i][j] -> moved == true))
				{
					grid[i][j] -> breed();
				}
			} // end for j


		}// end for i

		

}

// Defualt constructor of organism as a start 

Organism::Organism()
{
	world = NULL;
	moved = false ;
	breedFlag = 0 ;
	x = 0;
	y = 0 ;
}

//parametrised constructor 

Organism::Organism(World *wrld ,int x , int y)
{
	this->world = wrld ;
	moved = false ;
	breedFlag = 0;
	this->x = x;
	this->y = y ;
	wrld->setAt(x,y,this);

}

//Destrutcor

Organism::~Organism()
{	
}



/////////////////////////////

//Defualte consstructorr

Ant::Ant() : Organism()
{	
}

//parametrised constructor

Ant::Ant(World *world,int x ,int y) : Organism(world,x,y)
{	
}

//and here the  defintion of move function  for Ant which can move in four directions 

void Ant::move()
{
	// choose random direction to move
	int direction = rand() % 4 ;
	//try to move up,if not at an edge and empty cell
	if (direction==0)
	{
		if ((y>0)&& (world->getAt(x,y-1) == NULL))
		{
			world->setAt(x,y-1, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			y--;
		}
	}

	//try to move down
	else if (direction == 1)
	{
		if ((y < worldSize - 1)&& (world->getAt(x,y+1) == NULL))
		{
			world->setAt(x,y+1, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			y++;
		}
	}

	// try to move left
	else if (direction == 2)
	{
		if ((x>0)&& (world->getAt(x-1,y) == NULL))
		{
			world->setAt(x-1,y, world->getAt(x,y));

			//Move to new celll

			world->setAt(x,y,NULL);
			x--;
		}
	}

	// try to move right

	else
	{
		if ((x < worldSize - 1 )&& (world->getAt(x+1,y) == NULL))
		{
			world->setAt(x+1,y, world->getAt(x,y));

			//Move to new spot

			world->setAt(x,y,NULL);
			x++;
		}
	}

}

//Define getType function which return the type of creature(which is ant in this state)

int Ant::getType()
{
	return ant;
}

//Define breed function for ant it can eat after surviving 3 times

void Ant::breed()
{
	breedFlag++;
	if (breedFlag == antBreed)//is survive time of ant  equal to 3 
	{
		breedFlag = 0;
		//try to make new ant either above ,left,right
		if ((y>0) && (world->getAt(x , y - 1) == NULL))
		{
			Ant *newAnt = new Ant(world,x,y-1);
		}
		else if ((y<worldSize -1) && (world -> getAt(x,y+1) == NULL))
		{
			Ant *newAnt = new Ant(world,x,y+1);
		}
		else if ((x>0) && (world->getAt(x-1,y)== NULL))
		{
			Ant *newAnt = new Ant(world,x-1,y);
		}
		else if ((x<worldSize -1) && (world->getAt(x+1,y)== NULL))
		{
			Ant *newAnt = new Ant(world,x+1,y);
		}
	}
}

///////////////////////////////



//Defualte consstructorr

PoisonousAnt::PoisonousAnt() : Ant()
{	
}

//parametrised constructor 

PoisonousAnt::PoisonousAnt(World *world,int x ,int y) : Ant(world,x,y)
{	
}

//Defintion of move  function for poison ants same like normal ant

void PoisonousAnt::move()
{
	// choos random direction to move
	int direction = rand() % 4 ;
	//try to move up,if not at an edge and empty cell
	if (direction==0)
	{
		if ((y>0)&& (world->getAt(x,y-1) == NULL))
		{
			world->setAt(x,y-1, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			y--;
		}
	}

	//try to move down
	else if (direction == 1)
	{
		if ((y < worldSize - 1)&& (world->getAt(x,y+1) == NULL))
		{
			world->setAt(x,y+1, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			y++;
		}
	}

	// try to move left
	else if (direction == 2)
	{
		if ((x>0)&& (world->getAt(x-1,y) == NULL))
		{
			world->setAt(x-1,y, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			x--;
		}
	}

	// try to move right

	else
	{
		if ((x < worldSize - 1 )&& (world->getAt(x+1,y) == NULL))
		{
			world->setAt(x+1,y, world->getAt(x,y));

			//Move to new cell

			world->setAt(x,y,NULL);
			x++;
		}
	}

}

//Define getType function for poison ant which return only if there is mutation

int PoisonousAnt::getType()
{
	int randomNumber = rand() % 2  ;	// to check if there any mutation 
	// cout<<randomNumber;
	if (randomNumber == 1)
	{
		poison_ant = 1;
		return poison_ant;
	}
	else
		return 0;
	
}

//Define breed function for poison ant like ant breed function up

void PoisonousAnt::breed()
{
	breedFlag++;
	if (breedFlag == PoisonAntBreed)
	{
		breedFlag = 0;
		//try to make new posion ant either above ,left,right
		if ((y>0) && (world->getAt(x , y - 1) == NULL))
		{
			PoisonousAnt *newAnt = new PoisonousAnt(world,x,y-1);
		}
		else if ((y<worldSize -1) && (world -> getAt(x,y+1) == NULL))
		{
			PoisonousAnt *newAnt = new PoisonousAnt(world,x,y+1);
		}
		else if ((x>0) && (world->getAt(x-1,y)== NULL))
		{
			PoisonousAnt *newAnt = new PoisonousAnt(world,x-1,y);
		}
		else if ((x<worldSize -1) && (world->getAt(x+1,y)== NULL))
		{
			PoisonousAnt *newAnt = new PoisonousAnt(world,x+1,y);
		}
	}
}




// Defualt constructor
Doodlebug::Doodlebug(): Organism()
{
	starveFlag = 0;
}

//parametrised constructor
Doodlebug::Doodlebug(World *world , int x,int y):Organism(world,x,y)
{
	starveFlag = 0;
}

//Define move function for Doodle bug like move function of ant up
void Doodlebug::move()
{
	// The doodle bug can eat ant and sit in it's place 
	if ((y>0) &&(world->getAt(x,y-1))!= NULL && (world->getAt(x,y-1)->getType() == ant))
	{
		delete (world->grid[x][y-1]);
		world->grid[x][y-1] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		y--;
		return;
	}
	else if ((y < worldSize-1) && (world->getAt(x,y+1) != NULL) &&(world->getAt(x,y+1)->getType()== ant))
	{
		delete (world->grid[x][y+1]);
		world->grid[x][y+1] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		y++;
		return;
	}
	else if ((x>0) &&(world->getAt(x-1,y))!= NULL && (world->getAt(x-1,y)->getType() == ant))
	{
		delete (world->grid[x-1][y]);
		world->grid[x-1][y] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		x--;
		return;
	}

	else if ((x < worldSize-1) && (world->getAt(x+1,y) != NULL) &&(world->getAt(x+1,y)->getType()== ant))
	{
		delete (world->grid[x+1][y]);
		world->grid[x+1][y] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		x++;
		return;
	}

	///////////////////////////// and now for poison ant if Doodle bug eats poison ant it can only still for two time step
	if ((y>0) &&(world->getAt(x,y-1))!= NULL && (world->getAt(x,y-1)->getType() == poison_ant))
	{
		delete (world->grid[x][y-1]);
		world->grid[x][y-1] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		y--;
		return;
	}
	else if ((y < worldSize-1) && (world->getAt(x,y+1) != NULL) &&(world->getAt(x,y+1)->getType()== poison_ant))
	{
		delete (world->grid[x][y+1]);
		world->grid[x][y+1] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		y++;
		return;
	}
	else if ((x>0) &&(world->getAt(x-1,y))!= NULL && (world->getAt(x-1,y)->getType() == poison_ant))
	{
		delete (world->grid[x-1][y]);
		world->grid[x-1][y] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		x--;
		return;
	}

	else if ((x < worldSize-1) && (world->getAt(x+1,y) != NULL) &&(world->getAt(x+1,y)->getType()== poison_ant))
	{
		delete (world->grid[x+1][y]);
		world->grid[x+1][y] = this;
		world->setAt(x,y,NULL);
		starveFlag = 0;
		x++;
		return;
	}


	// and here for normal movment it checks in all directions if its possible to move 
	int direction = rand() % 4 ;
	//try to move up ,

	if (direction==0)
	{
		if ((y>0)&& (world->getAt(x,y-1) == NULL))
		{
			world->setAt(x,y-1, world->getAt(x,y));

			//Move to new spot

			world->setAt(x,y,NULL);
			y--;
		}
	}

	//try to move down
	else if (direction == 1)
	{
		if ((y < worldSize - 1)&& (world->getAt(x,y+1) == NULL))
		{
			// move to new spot
			world->setAt(x,y+1, world->getAt(x,y));

			// and set current spot to empty 

			world->setAt(x,y,NULL);
			y++;
		}
	}

	// try to move left
	else if (direction == 2)
	{
		if ((x>0)&& (world->getAt(x-1,y) == NULL))
		{
			// move to new spot
			world->setAt(x-1,y, world->getAt(x,y));

			//and set the current spot to empty

			world->setAt(x,y,NULL);
			x--;
		}
	}

	// try to move right

	else
	{
		if ((x < worldSize - 1 )&& (world->getAt(x+1,y) == NULL))
		{
			//Move to new spot
			world->setAt(x+1,y, world->getAt(x,y));

			// and set current spot to empty
			world->setAt(x,y,NULL);
			x++;
		}
	}
	// end of movement options

	//and now increment starveFlag because it did'nt eat on this turn
	starveFlag++;// to check it later 

	


}

// define getType function for Doodlebug class to return creature type 

int Doodlebug::getType()
{
	return doodleBug;

}


// define breed function for doodle bug just like ants  but here it will check for 8 times

void Doodlebug::breed()
{
	breedFlag++;
	if (breedFlag == doodleBreed)
	{
		breedFlag = 0;
		//try to make new ant either up,left,down,or right
		if ((y>0) && (world->getAt(x,y-1) == NULL))
		{
			Doodlebug *newDoolde = new Doodlebug(world,x,y-1);
		}
		else if ((y < worldSize-1) && (world->getAt(x,y+1) == NULL))
		{
			Doodlebug *newDoolde = new  Doodlebug(world,x,y+1);
		}
		// end for y states now lets do it for x states
		else if ((x>0) && (world->getAt(x-1,y) == NULL))
		{
			Doodlebug *newDoolde = new Doodlebug(world,x-1,y);
		}
		else 
		{
			Doodlebug *newDoolde = new  Doodlebug(world,x+1,y);
		}
		// end for x states

	}
}


// starve function definition

bool Doodlebug::starve()
{
	//starve if no food eaten in last turn
	if (starveFlag > doodleStarve)
	{
		return true;
	}
	else
		return false;
} 
