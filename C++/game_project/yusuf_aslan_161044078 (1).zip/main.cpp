#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <time.h>
#include "simulation.h"
using namespace std;



//////////////////////////////main function

int main()
{


	// and now define world object
	World obj;
	//define random number generator will be used to creat insects to use in simulation
	srand(time(NULL));



	// cout<<"all tamam1 !!\n";
	// create  5 doodleBugs randomly and put them in the appropriate cells  
	int countOfDoodle = 0;
	while(countOfDoodle < intialBugs)
	{
		int x = rand() % worldSize;
		int y = rand() % worldSize;

		// create and put new  doodleBug in empty cells only
		if (obj.getAt(x,y) == NULL)
		{
			countOfDoodle++;
			Doodlebug * doodle = new Doodlebug(&obj,x,y);
		}
	}

	///////////


	//also make 100 ants randolmy and put them in the appropriate cells
	int countOfAnts = 0 ;
	while(countOfAnts < intialAnts)
	{
		int x = rand() % worldSize;
		int y = rand() % worldSize;

		//  put new  ants in empty cells only
		if (obj.getAt(x,y) == NULL)
		{
			countOfAnts++;
			Ant * annt = new Ant(&obj,x,y);
		}
	}

	
	//string will be use to take Enter key  from user after every turn 
	string str;
	
	//and now run a simulation which contiune turn after turn with enters from user  until user cancel
	while(true){
		obj.display();	
		obj.simulateOneStep();
		
		cout<<"\nPress enter for next step"<<endl;
		getline(cin,str);
		
	} 



	return 0;
}