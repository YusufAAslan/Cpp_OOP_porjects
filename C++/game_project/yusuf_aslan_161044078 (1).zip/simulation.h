// header file  includes the wanted classes and the simulation 
/**/
#ifndef Simulation_h
#define Simulation_h



// Declare our global constants  variabes taken from given pdf
const int worldSize = 30 ;  // we can put any size to show the simulation I choosed 30  
const int intialAnts = 100;	// form the pdf 
const int intialBugs = 5;// form the pdf  and used in main.cpp
const int doodleBug = 1;// form the pdf 
const int ant = 2;// form the pdf 
const int antBreed = 3;// form the pdf to breed after 3 times  of surviving
const int PoisonAntBreed = 4;//form pdf  to breed after 4 times of surviving
const int doodleBreed = 8;// form the pdf   to breed after 8 times of surviving
const int doodleStarve = 3;// form the pdf  to check if doodlebu starved
/////////////////////////////


// Forward declaration of our classes

class Organism ; 
class Doodlebug ;
class Ant;
class PoisonousAnt;
class World; 


///////////////
// creat a class name world to do and display the simulation at the end and it's friend to all class that we need 

class World
{
	friend class Organism;
	friend class Doodlebug;
	friend class Ant ;
	friend class PoisonousAnt;

private:
	Organism* grid[worldSize][worldSize];

public:

	//constructor
	World();
	// and of cours desturctor
	~World(){

	};


	//member functions to use 

	Organism* getAt(int x, int y);
	void setAt(int x , int y,Organism *org);
	void display();
	void simulateOneStep();



};
//////////////////////// end of class world



// Create a class named Organism that encapsulates basic data common to both
//ants, and doodlebugs. This class  have a virtual function named move that is defined in the derived classes of
//Ant and Doodlebug

class Organism
{
	//Also this class will be friend to world class becuase world class will make changes on it  
	friend class World;
public:
	//constructors
	Organism();
	Organism(World *world,int x , int y);
	//destructor
	~Organism();
	//member functions to use 
	virtual void breed() = 0 ;
	virtual void move() = 0 ;
	virtual int getType() = 0 ;
	virtual bool starve() = 0 ;
protected:
	//some  variables will be needed
	int x , y ;
	bool moved;
	int breedFlag;
	World *world ;

};

///////////////// end pf organism class




///////////////////////////////////////////
// start with the Ant class which derived from Organism and friend to class world also has same member functions like doodlebug

class Ant :public Organism
{
	friend class World;
public:
	//constructor
	Ant();
	Ant(World *world , int x ,int y);

	//Methods 
	void breed();
	void move();
	int getType();
	bool starve()
	{
		return false;
	}

};


//////////////////////////////////////////////////////////
// and now lets wirte  the posion Ant class which derived from Ant class  and it has small probability to occure

class PoisonousAnt :public Ant
{
	friend class World;
	friend class Organism;
public:
	//constructor
	PoisonousAnt();
	// parameterised constructor
	PoisonousAnt(World *world , int x ,int y);

	//member functions to use  
	void breed();
	void move();
	int getType();
	bool starve()
	{
		return false;
	}

};

//

// creat a class Doodlebug which is derived from organism and has some member functions
class Doodlebug : Organism
{
	friend class World;
public:
	Doodlebug();
	Doodlebug(World *world,int x,int y);
	void breed();
	void move();
	int getType();
	bool starve();
private:
	int starveFlag;


};




#endif /*Simulation_h*/
