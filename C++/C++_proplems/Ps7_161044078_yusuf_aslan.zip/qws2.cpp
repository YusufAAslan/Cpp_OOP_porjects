#include <iostream>
#include <string>
using namespace std;

	/* student class */

class student

{

	public:

	/* Constructor */
	student();

	/* Destructor that releases all memory that has been allocated.*/
	~student();

	/* Function to take inputs from user */
	void input_data();

	/* Funcion to print output */
	void output();


	/* Function to reset the classes */
	void resetClass();

	/* An overloaded assignment operator */
	student& operator =(const student& over_load_assign);

	private:

	/*Our varaibles */

	string name;			/*A string that stores the name of the student*/

	int numClasses ;		/*An integer that tracks how many courses the student is currently enrolled in*/

	string *student_enrolled_classes;	/*A dynamic array of strings used to store the names of the classes that the student is enrolled in*/

};


/*------------------------------------- main---------------------------------------------------------------------- */




int main()

{

student obj1, obj2;

/* Taking inputs from Student1 */

obj1.input_data();

cout << "Student1's information: " << endl;

/* print the output for Student1 */

obj1.output();

cout << endl;

obj2 = obj1;

cout << "Student2's information after assignment from Student1:" << endl;

/* Output same data as the Student1 */

obj2.output();

/*Reset the Class */

obj1.resetClass();
cout<<endl;
cout << "Student1's information after calling reset:" << endl;

/* Must have no Classes */

obj1.output();

/* Must have Original Classes */
cout<<endl;	
cout << "Student2's information should be  no name and original classes from student1:" << endl;

obj2.output();

cout << endl;

return 0 ;
}


/*-----------------------------------------------functions's defintions--------------------------------------------------*/


void student::input_data()				/*This function to take inputs from user arbitrary*/

{

	resetClass();

	cout << "Student name: ";

	getline(cin, name);
	// cout<<name<<endl;

	cout << "Number of classes: ";

	cin >> numClasses ;
	// cout<<numClasses<<endl;
	cin.ignore(2,'\n');					/*I used this function to clear buffer before taking newline*/

	if (numClasses  > 0)

	{

	student_enrolled_classes = new string[numClasses ];		/*new operator initializes the memory and returns the address of the newly allocated and initialized memory to the pointer variable.*/

	for (int i=0; i<numClasses ; i++)

	{

	cout << "Name of the class " << (i+1) << " : ";

	getline(cin, student_enrolled_classes[i]);

	}

	}

	cout << endl;

}





void student::output()			/*A function that prints the name and list of all courses*/

{

	cout << "Name of the Student: " << name << endl

	<< "ClassList: " << endl<<endl;

	for (int i = 0; i < numClasses ; i++)

	{

	cout<< i + 1 << ") " << student_enrolled_classes[i] << endl;

	}

}




/* Copy Constructor */

student::student() : name(""), numClasses (0), student_enrolled_classes(NULL){}





/* Destructor to reset  */

student::~student()

{

	numClasses  = 0;

	resetClass();

	name = "";

}





void student::resetClass()		/*A function that resets the number of classes to 0 and the classList to an empty list.*/

{

	if (student_enrolled_classes)

	{

	delete [] student_enrolled_classes;			/*Becuase we used new keyword to allocate memory 
												here we use delete keyword to deallocate that memory and for arrays we put delete[]*/

	student_enrolled_classes = NULL;

	numClasses  = 0;

	}

}




/* An overloaded assignment operator that correctly makes a new copy of the list of courses. */

student& student::operator =(const student& over_load_assign)		

{

	resetClass();

	numClasses  = over_load_assign.numClasses ;

	if (numClasses  > 0)

	{

	student_enrolled_classes = new string[numClasses ];		/*new operator initializes the memory and returns the address of the newly allocated and initialized memory to the pointer variable.*/

	for (int i = 0; i < numClasses ; i++)

	{

	student_enrolled_classes[i] = over_load_assign.student_enrolled_classes[i];

	}

	}

	return *this;		/*This here refer to the obj we used here (over_load_assign)*/

}
