#include <iostream>
#include <cstring>				/*While we will accept c string*/



using namespace std;



int main() {

	string str;
	char *head, *tail, *after_reversing_str;
	int i = 0;

	cout << "Enter a string: ";

	getline(cin, str);		/*Take the string from user*/


	after_reversing_str = new char[str.size() + 1];				/*Here we created a pointer named c, initialised to point to a memory location where there is enough room for string size  characters*/

	strcpy(after_reversing_str,str.c_str());					/*Here we convert c++ string to c style string*/



	head = &after_reversing_str[0];				/*Here we put head at the beginning*/

	tail = &after_reversing_str[str.size() - 1];	/*Here we put tail at the end -1 */



	cout << "String inverted is: ";


	char temp;

	while (head <= tail) /* This loop  will be done only halfway of string , not for complete string, becuase we are swapping them now */

	{

		temp = after_reversing_str[i];
		after_reversing_str[i] = *tail;
		*tail = temp;
		*tail--;
		*head++;

		i++;

	}




	/*And now print the reversed string*/
	cout << after_reversing_str;



	cout <<"\n";



	return 0;

}