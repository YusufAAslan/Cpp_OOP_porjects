#include <iostream>


using namespace std;




int take_fibonacci_number(int n);	/*Desired recursive function*/


int main()
{
    cout << " Enter which index you want from Fibonacci series: ";
    int number = 0;
    cin >> number;

    cout << " Fibonacci number is: " << take_fibonacci_number(number) << endl;

    return 0;

}




int take_fibonacci_number(int n)
{
    if(n < 2 )	/* The fibbonacci number for numbers between 0-2 is the number it self(for 0 is 0, for 1 is 1 */
        return n;
    else
        return take_fibonacci_number(n - 1) + take_fibonacci_number(n - 2); /*applying the equation of fibbonacci series*/
}