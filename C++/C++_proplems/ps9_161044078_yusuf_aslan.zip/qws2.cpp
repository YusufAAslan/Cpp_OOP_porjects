#include <iostream>
#include <cstring>

using namespace std;

void reverse_string_with_two_indexes(char *arr, const int first_index, const int second_index);
void revers_string_completely(char str[]);



////////////////////main
int main()
{
	   //Character array
	char str[] = {'A', 'B', 'C', 'D', 'E', '\0'};

	   //C String to reverse
	char something[] = "hi bye";

	//Printing char array before reverse
	cout << "Char array before reversing : " << str << " \n";

	int first_index,second_index;
	cout<<"Please enter your indexes\n";
	cin>>first_index>>second_index;
	reverse_string_with_two_indexes(str, first_index,second_index);

	cout << "Char array after reversing with two indexes: " << str << " \n";


	/////////Next part

	cout << "Our string before reversing: " << something << " \n";

	//calling our function
	revers_string_completely(something);

	cout << "Our string after reversing: " << something << " \n";


	return 0;
}




void reverse_string_with_two_indexes(char *arr, const int first_index, const int second_index)

{
	//Base condtion(terminal)
     if (first_index > second_index)

          return;

    char temp;

    temp = arr[first_index];

    arr[first_index] = arr[second_index];

    arr[second_index] = temp;

    reverse_string_with_two_indexes(arr, first_index + 1, second_index - 1);

}



//Function  reverses the hall string
void revers_string_completely(char str[])
{
	//Taking start  as 0, and end as length - 1
	int start = 0, end = strlen(str)-1;

	//Calling function with start and end bounds
	reverse_string_with_two_indexes(str, start, end);
}