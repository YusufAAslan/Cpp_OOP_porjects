#include <iostream>
#include <cstring>

using namespace std;

//Function prototypes
void reverse_array_of_char_with_two_indexes(char str[],int first_index, int second_index);
void reverse_string_completly(char str[]);


///////////////Main function



int main()
{
   //Character array
	char str[] = {'A', 'B', 'C', 'D', 'E','F','G','\0'};

	   //C String to reverse
	char some_thing[] = "Hi bye";
	int first_index ;
	int second_index;

	//Printing char array before reverse
	cout << "Your string before reversing : " << str << " \n";

	cout<<"Please enter two integer bouderis "<<endl;
	cin>>first_index>>second_index;
	//Reversing char array using bounds 1, 4
	reverse_array_of_char_with_two_indexes(str, first_index,second_index);

	//Printing char array after reverse
	cout << "Your string after reversing with bounds("<<first_index<<","<<second_index<<")is: " << str << " \n";

	cout<<"Next part:\n";
	//Reversing string

	cout<<"your string befor reversing is : "<<some_thing<<endl;
	reverse_string_completly(some_thing);


	//C String after reversing
	cout << "your string befor reversing is :" << some_thing << " \n";



	return 0;
}




//Function that reverse the char array with it's bounds
void reverse_array_of_char_with_two_indexes(char str[], int first_index, int second_index)
{
	int i, j;
	char temp;
	int len;

	//Finding length by using strlen function
	len = strlen(str);

	//Checking for invalid indexes
	if(first_index < 0 || second_index >= len)
	{
		cout << "\n\n Invalid Bounds.... \n\n";
		return;
	}


	j = first_index;

	for(i=second_index; i>(second_index)/2; i--)
	{
		//Using temp to store the char value at index i so 
    	//you can swap it in later for char value at index n
		//Swapping characters
		temp = str[i];
		str[i] = str[j];
		str[j] = temp;

		j++;
	}
}




//Function that reverses the string by using loop
void reverse_string_completly(char str[])
{
	int len = strlen(str);
  	int n=len-1;
  	char temp ;

  	for(int i=0;i<(len/2);i++){

    	//Using temp to store the char value at index i so 
    	//you can swap it in later for char value at index n
    	temp = str[i];
    	str[i] = str[n];
    	str[n] = temp;
    	n = n-1;

  }
}
