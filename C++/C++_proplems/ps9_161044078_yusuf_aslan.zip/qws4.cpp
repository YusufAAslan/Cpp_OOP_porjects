#include <iostream>


using namespace std;
void hanoi_tower(int number,int needle1,int needle2,int helper); /*number: count of diskes ,needle1 and needle2 and helper our parts*/



int main()
{
	int number;
	cout<<"Enter number of disks: " ;
	cin>>number;
	cout<<endl;
	hanoi_tower(number,1,3,2);


	return 0;
}



void hanoi_tower(int number,int needle1,int needle2,int helper)
{
	if(number==1)
		cout<<"Disk number "<<number<<" moving from "<<needle1<<" to "<<needle2<<endl;
	else
	{
		hanoi_tower(number-1,needle1,helper,needle2);
		cout<<"Disk number "<<number<<" moving from "<<needle1<<" to "<<needle2<<endl;
		hanoi_tower(number-1,helper,needle2,needle1);
	}
}