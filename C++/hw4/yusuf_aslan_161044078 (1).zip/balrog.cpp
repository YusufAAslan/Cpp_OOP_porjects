//barlog.cpp  balrog class implimentation 
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "balrog.h"
#include "demon.h"
using namespace std;

//Default constructor
balrog::balrog():demon()
{
}

//Constructor
balrog::balrog(int newStrength, int newHitpoints):demon(newStrength, newHitpoints)
{
}

//Define getDamage function for balrogs(which are demons)
int balrog::getDamage()
{
   int value = demon::getDamage();
   int randValue = ((rand() % balrog::getStrength()) + 1);
   cout << " The balrog's rampage does " << randValue << " damage! " << endl;
   value = (value + randValue);
   return value;
}


//Define getSpecies for balrogs
string balrog::getSpecies() const
{
   return "balrog";
}