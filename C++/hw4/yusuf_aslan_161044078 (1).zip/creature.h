//creature.h Defining creature class like in the pdf
#ifndef CREATURE_H
#define CREATURE_H
#include <string>


class creature
{
private:
   int type;
   int strength;
   int hitpoints;

public:
   creature();
   creature(int newStrength, int newHitpoints);
   creature(int newType, int newStrength, int newHitpoints);
   virtual int getDamage();

   //accessors and mutators
   virtual std::string getSpecies() const = 0;
   int getHitpoints();
   int getStrength();

   void setHitpoints(int newHitpoints);
   void setStrength(int newStrength);
};
#endif