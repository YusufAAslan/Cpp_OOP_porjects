//cyberdemon.cpp (constructors and getspecies function)
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "cyberdemon.h"
#include "demon.h"
using namespace std;



//Default constructor
cyberdemon::cyberdemon():demon()

{
}


//Consturtor and it's arguments
cyberdemon::cyberdemon(int newStrength, int newhitpoints):demon(newStrength, newhitpoints)
{
}


//Define getSpecies for cyberdemons (which is demons)
string cyberdemon::getSpecies() const
{
   return "cyberdemon";
}