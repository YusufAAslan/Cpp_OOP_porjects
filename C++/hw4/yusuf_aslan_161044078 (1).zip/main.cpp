//main test file with random attacks
#include <iostream>
#include "creature.h"
#include "demon.h"
#include "human.h"
#include "elf.h"
#include "cyberdemon.h"
#include "balrog.h"
#include <ctime>
#include <cstdlib>
#include <string>

using namespace std;



// test with random numbers
int main()
{

  srand(time(0));

  human h1;
  elf e1;
  cyberdemon c1;
  balrog b1;
  human h(10, 20);
  elf e(30, 40);
  cyberdemon c(50, 60);
  balrog b(70, 80);

  cout << " Human (strength/hitpoints) given at the beginning: " << h1.getStrength()<< "/" << h1.getHitpoints() << endl << endl;
  cout << " Elf (strength/hitpoints) given at the beginning: " << e1.getStrength() << "/" << e1.getHitpoints() << endl << endl;
  cout << " Cyberdemon (strength/hitpoints) given at the beginning: " <<c1.getStrength() << "/" << c1.getHitpoints() << endl << endl;
  cout << " Balrog (strength/hitpoints) given at the beginning: " << b1.getStrength()<< "/" << b1.getHitpoints() << endl << endl;
  cout << "given in main human (strength/hitpoints): " <<h.getStrength() << "/" << h.getHitpoints() << endl << endl;
  cout << "given in main elf (strength/hitpoints): " << e.getStrength()<< "/" << e.getHitpoints() << endl << endl;
  cout << "given in main cyberdemon (strength/hitpoints): " <<c.getStrength() << "/" << c.getHitpoints() << endl << endl;
  cout << "given in main balrog (strength/hitpoints): " <<b.getStrength() << "/" << b.getHitpoints() << endl << endl;
  cout << endl << endl<<endl;



  cout << "Examples of " << h.getSpecies() << " damage: " << endl;
  for (int i = 0; i < 10; i++) {
    int damage = h.getDamage();
    cout << " ! Total damage ! = " << damage << endl;
    cout << endl;
   }
  cout << endl<<endl;


  cout << "Examples of " << e.getSpecies() << " damage: " << endl;
  for (int i = 0; i < 10; i++) {
    int damage = e.getDamage();
    cout << " ! Total damage ! = " << damage << endl;
    cout << endl;
   }
  cout << endl << endl;


  cout << "Examples of " << c.getSpecies() << " damage: " << endl;
  for (int i = 0; i < 10; i++) {
    int damage = c.getDamage();
    cout << " ! Total damage ! = " << damage << endl;
    cout << endl;
   }
  cout << endl << endl;


  cout << "Examples of " << b.getSpecies() << " damage: " << endl;
  for (int i = 0; i < 10; i++) {
    int damage = b.getDamage();
    cout << " ! Total damage ! = " << damage << endl;
    cout << endl;
   }
  // cout << endl << endl;


  return 0;
}