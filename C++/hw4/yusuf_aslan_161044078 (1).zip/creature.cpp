//creature.cpp creature class implimentation
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "creature.h"
using namespace std;

//Default constructor
creature::creature()
{
   hitpoints = 10;
   strength = 10;
   srand(time(0));
}


//Constructor with  arguments
creature::creature(int newStrength, int newHitpoints)
{
   hitpoints = newHitpoints;
   strength = newStrength;
   srand(time(0));
}


//Constructor with  arguments
creature::creature(int newType, int newStrength, int newHitpoints)
{
   type = newType;
   hitpoints = newHitpoints;
   strength = newStrength;
   srand(time(0));
}


//Define setStrength function for creature
void creature::setStrength(int newStrength)
{
   strength = newStrength;
}


//Define getStrength function for creature
int creature::getStrength()
{
   return strength;
}


//Define setHitpoints function for creature
void creature::setHitpoints(int newHitpoints)
{
   hitpoints = newHitpoints;
}


//Method definition of getHitpoints
int creature::getHitpoints()
{
   return hitpoints;
}


//Method definition of getDamage
int creature::getDamage()
{
   int value;
   value = ((rand() % strength) + 1);
   cout << "The " << getSpecies() << " attacks for " << value << " points!" << endl;
   return value;
}
