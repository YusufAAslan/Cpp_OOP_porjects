//barlog.h (balrog class definition)
#ifndef BALROG_H
#define BALROG_H
#include "demon.h"



class balrog : public demon
{
public:
   balrog();
   balrog(int newStrength, int newHitpoints);
   int getDamage();
   std::string getSpecies() const;
};
#endif

