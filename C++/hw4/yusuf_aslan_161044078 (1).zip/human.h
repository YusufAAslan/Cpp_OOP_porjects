//human.h file  and definition
#ifndef HUMAN_H
#define HUMAN_H
#include "creature.h"
#include <iostream>
#include <string>

using namespace std;	


//definition of human class by using inheritance


class human : public creature
{
public:
   human();
   human(int newStrength, int newHitpoints);
   string getSpecies() const;
};
#endif
