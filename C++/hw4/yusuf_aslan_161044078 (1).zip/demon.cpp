//demon.cpp and class implimentation
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "creature.h"
#include "demon.h"
using namespace std;


//Default constructor
demon::demon():creature()
{
}


//Constructor with arguments
demon::demon(int newStrength, int newHitpoints):creature(newStrength, newHitpoints)
{
}



//Define getDamage function for demon with 5% damage  
int demon::getDamage()
{
   int value = creature::getDamage();
   if (rand() % 5 == 1)
   {
    cout << "Demonic Rage inflicts 50 additional damage points ! " << endl;
    value = (value + 50);
   }
   return value;
}


// Define getSpecies function for demons
string demon::getSpecies() const
{
   return "demon";
}