//elf.h file and  class definition 
#ifndef ELF_H
#define ELF_H
#include "creature.h"


class elf : public creature
{
public:
  elf();
  elf(int newStrength, int newHitpoints);
  int getDamage();
  std::string getSpecies() const;
};
#endif
