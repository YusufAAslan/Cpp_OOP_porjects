//human.cpp file and the implimintation
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "creature.h"
#include "human.h"


using namespace std;


//constructor
human::human():creature()
{
}


//constrctor and it's arguments
human::human(int newStrength, int newHitpoints):creature(newStrength, newHitpoints)
{
}


//Define getSpecies  function for human
string human::getSpecies() const
{
   return "human";
}